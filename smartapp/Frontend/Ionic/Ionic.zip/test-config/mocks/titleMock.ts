export class TitleMock {
  public setTitle(title: string): void {
    return;
  }
}