import { StatusBar } from '@ionic-native/status-bar';

export class StatusBarMock extends StatusBar {
  styleDefault() {
    return;
  }
}