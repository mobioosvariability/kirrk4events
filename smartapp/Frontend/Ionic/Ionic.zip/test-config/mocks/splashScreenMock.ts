import { SplashScreen } from '@ionic-native/splash-screen';

export class SplashScreenMock extends SplashScreen {
  hide() {
    return;
  }
}